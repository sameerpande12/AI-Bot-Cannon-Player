g++ cannon.cpp -o cannon
